﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Életjáték_VZJ0UE
{
    public partial class Form1 : Form
    {

        int hanyegyes = 0;
        bool[,] pálya = new bool[40, 40];
        bool[,] újPálya = new bool[40, 40];
        Random rnd = new Random();
        Timer timer = new Timer();

        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            button1.Click += button1_Click;
            button2.Click += button2_Click;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            randomigaz();
            Színezés();
            timer.Enabled = true;
            timer.Interval = 200;
            timer.Tick += Timer_Tick;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            ujpalya_szamitas();
            for (int i = 0; i < 40; i++)
            {
                for (int j = 0; j < 40; j++)
                {
                    pálya[i, j] = újPálya[i, j];
                }
            }
            Színezés();

        }

        public void ujpalya_szamitas()
        {
            for (int i = 0; i < 40; i++)
            {
                for (int j = 0; j < 40; j++)
                {
                    if (mezőÉrtéke(i - 1, j - 1, pálya ) == 1) hanyegyes++;
                    if (mezőÉrtéke(i, j - 1, pálya) == 1) hanyegyes++;
                    if (mezőÉrtéke(i + 1, j - 1, pálya) == 1) hanyegyes++;
                    if (mezőÉrtéke(i - 1, j, pálya) == 1) hanyegyes++;
                    if (mezőÉrtéke(i + 1, j, pálya) == 1) hanyegyes++;
                    if (mezőÉrtéke(i - 1, j + 1, pálya) == 1) hanyegyes++;
                    if (mezőÉrtéke(i, j + 1, pálya) == 1) hanyegyes++;
                    if (mezőÉrtéke(i + 1, j + 1, pálya) == 1) hanyegyes++;

                    if (pálya[i, j] == true)
                    {
                        if (hanyegyes < 2 || hanyegyes > 3) újPálya[i, j] = false;
                    }
                    else
                    {
                        if (hanyegyes == 3) újPálya[i, j] = true;
                    }

                    hanyegyes = 0;

                }
            }
        }
        public int mezőÉrtéke(int sor, int oszlop, bool[,] p)
        {
            if (sor > p.GetUpperBound(0)) return 0;
            if (oszlop > p.GetUpperBound(1)) return 0;
            if (sor < 0 || oszlop < 0) return 0;
            return (p[sor, oszlop] == true ? 1 : 0);
        }

        public void randomigaz() 
        {
            for (int sor = 0; sor < 40; sor++)
            {
                for (int oszlop = 0; oszlop < 40; oszlop++)
                {

                    int o = rnd.Next(1600);
                    if (o < 600)
                    {
                        pálya[sor, oszlop] = true;
                    }
                    else
                    {
                        pálya[sor, oszlop] = false;
                    }

                }
            }
        }
        public void Színezés()
        {
            //Controls.Clear();

            for (int i = 0; i < 40; i++)
            {
                for(int j = 0; j < 40; j++)
                {

                    //Képkocka kk = new Képkocka();
                    //Controls.Add(kk);
                    Graphics rajz = this.CreateGraphics();
 
                    //kk.Left = i * (kk.Width + 1) + 320;
                    //kk.Top = j * (kk.Height + 1);

                    if (pálya[i, j] == true)
                    {
                        Brush ecset = new SolidBrush(Color.Blue);
                        rajz.FillRectangle(ecset,(i * 15) + 350 , (j * 15)+ 18, 12,12);
                        //kk.BackColor = Color.Blue;
                    }
                    if (pálya[i, j] == false)
                    {
                        Brush ecset2 = new SolidBrush(Color.Yellow);
                        rajz.FillRectangle(ecset2, (i * 15) + 350 , (j * 15) + 18, 12, 12);
                        //kk.BackColor = Color.Yellow;
                    }

                }
            }
            
        }


    }
            
}
